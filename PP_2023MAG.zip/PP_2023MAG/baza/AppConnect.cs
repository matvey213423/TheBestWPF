﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PP_2023MAG.baza
{
    public class AppConnect
    {
        public static PPMAG_20023Entities1 model0db;

    }
}
