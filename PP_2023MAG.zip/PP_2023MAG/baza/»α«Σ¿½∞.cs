﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace PP_2023MAG.baza
{
    public class профиль
    {
       static public Пользователи пользователь;
    }
}
