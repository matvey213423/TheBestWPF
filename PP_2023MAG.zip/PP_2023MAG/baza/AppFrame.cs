﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace PP_2023MAG.baza
{
    public class AppFrame
    {
        public static Frame frameMain;

    }
}
