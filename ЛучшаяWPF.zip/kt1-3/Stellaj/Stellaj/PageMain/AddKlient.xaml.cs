﻿using Stellaj.ApplicationData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Stellaj.PageMain
{
    /// <summary>
    /// Логика взаимодействия для AddKlient.xaml
    /// </summary>
    public partial class AddKlient : Page
    {
        private Klient _currentHotel = new Klient();
        public AddKlient(Klient selectedHotel)
        {

            InitializeComponent();
            if (selectedHotel != null)
                _currentHotel = selectedHotel;

            DataContext = _currentHotel;
           
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_currentHotel.FIO))
                errors.AppendLine("Укажите ФИО");
            if (string.IsNullOrWhiteSpace(_currentHotel.NumberScore))
                errors.AppendLine("Укажите Номер");
            if (string.IsNullOrWhiteSpace(_currentHotel.Adress))
                errors.AppendLine("Укажите адресс");
            if (string.IsNullOrWhiteSpace(_currentHotel.Tariff))
                errors.AppendLine("Укажите Тариф");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentHotel.Money)))
                errors.AppendLine("Укажите баланс счёта");

            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }


            if (_currentHotel.ID == 0)
                user13Entities.GetContext().Klients.Add(_currentHotel);

            try
            {
                user13Entities.GetContext().SaveChanges();
                MessageBox.Show("Информация сохранена!");
                AppFrame.frameMain.Navigate(new Klients());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
