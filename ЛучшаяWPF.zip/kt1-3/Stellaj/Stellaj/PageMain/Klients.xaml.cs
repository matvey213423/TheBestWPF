﻿using Stellaj.ApplicationData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Stellaj.PageMain
{
    /// <summary>
    /// Логика взаимодействия для Klients.xaml
    /// </summary>
    public partial class Klients : Page
    {
        public Klients()
        {
            InitializeComponent();
            DGridKlients.ItemsSource = user13Entities.GetContext().Klients.ToList();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new AddKlient(null));
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {

            Klient hotelsForRemoving = (Klient)DGridKlients.SelectedItems[0];
            AppFrame.frameMain.Navigate(new AddKlient(hotelsForRemoving));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var hotelsForRemoving = DGridKlients.SelectedItems.Cast<Klient>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следуюцие {hotelsForRemoving.Count()} элементов?", "Внимание",
            MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    user13Entities.GetContext().Klients.RemoveRange(hotelsForRemoving);
                    user13Entities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DGridKlients.ItemsSource = user13Entities.GetContext().Klients.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }



            }
        }
    }
}
